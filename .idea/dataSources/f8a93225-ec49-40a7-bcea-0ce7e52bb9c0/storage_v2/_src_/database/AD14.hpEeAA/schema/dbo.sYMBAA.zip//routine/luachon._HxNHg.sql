create procedure luachon
	@IdBB int
as
begin
	select * from BienBan where BienBan.Id = @IdBB;
end;
go

