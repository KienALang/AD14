create procedure [dbo].[luachon]
    @IdBB int
as
  begin
    select * from BienBan where BienBan.IdBienBan = @IdBB;
  end;
go

